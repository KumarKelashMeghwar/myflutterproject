const Task = require("../Models/Tasks");

const GetAllTasks = async (req, res) => {
  let tasks = await Task.find();

  if (tasks.length != 0) {
    res.send({ data: tasks });
  } else {
    res.json("tasks not found!");
  }
};

module.exports = { GetAllTasks };
