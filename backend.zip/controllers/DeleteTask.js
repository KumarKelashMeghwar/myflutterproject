const Task = require("../Models/Tasks");

const DeleteTask = async (req, res) => {
  let response = await Task.deleteOne({ _id: req.body.id });

  if (response.deletedCount > 0) {
    res.send("Deleted task successfully!");
  } else {
    res.send("Failed to delete the task");
  }
};

module.exports = { DeleteTask };
