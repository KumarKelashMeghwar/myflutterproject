const Tasks = require("../Models/Tasks");

const AddTask = async (req, res) => {
  let Task = new Tasks({
    name: req.body.name,
  });

  if (Task.name) {
    Task.save();
    res.send("Task has been saved");
  } else {
    res.send("Some error has occured!!!");
  }
};

module.exports = { AddTask };
