const User = require("../Models/Users");

const GetAll = async (req, res) => {
  let users = await User.find();

  if (users.length != 0) {
    res.send({ data: users });
  } else {
    res.json("users not found!");
  }
};

module.exports = { GetAll };
