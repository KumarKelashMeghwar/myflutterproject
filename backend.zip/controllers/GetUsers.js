const User = require("../Models/Users");

const GetUsers = async (req, res) => {
  let { email, password } = req.body;

  let users = await User.find({ email, password });

  if (users.length != 0) {
    res.send({ data: users });
  } else {
    res.status(404).json("users not found!");
  }
};

module.exports = { GetUsers };
