const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const app = express();
require("dotenv").config();

app.use(express.json());
app.use(cors());

mongoose.connect(process.env.MONGO_URL, { useNewUrlParser: true });
const db = mongoose.connection;
db.on("error", console.error.bind(console, "MongoDB connection error:"));

const { GetUsers } = require("./controllers/GetUsers");
const { GetAll } = require("./controllers/GetAll");
const { GetAllTasks } = require("./controllers/GetAllTasks");
const { AddTask } = require("./controllers/AddTask");
const { DeleteTask } = require("./controllers/DeleteTask");

app.get("/", (req, res) => {
  res.send("welcome to my app");
});

// for user
app.post("/getusers", GetUsers);

app.post("/getall", GetAll);


// for tasks
app.post("/gettasks", GetAllTasks);

app.post("/addtask", AddTask);

app.post("/deletetask", DeleteTask);

app.listen(3400, () => {
  console.log("Backend is running on 3400");
});
