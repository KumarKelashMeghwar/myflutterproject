const mongoose = require("mongoose");
const TaskSchema = new mongoose.Schema(
  {
    name: String,
  },
  {
    collection: "Tasks",
  }
);

module.exports = mongoose.model("tasks", TaskSchema);
