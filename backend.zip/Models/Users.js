const mongoose = require("mongoose");
const UserSchema = new mongoose.Schema(
  {
    email: String,
    password: String,
  },
  {
    collection: "Users",
  }
);

module.exports = mongoose.model("users", UserSchema);
